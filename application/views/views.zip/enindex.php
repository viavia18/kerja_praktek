<!--================Home Banner Area =================-->
<section class="home_banner_area">
    <div class="banner_inner d-flex align-items-center">
        <div class="overlay bg-parallax" data-stellar-ratio="0.9" data-stellar-vertical-offset="0" data-background="">
        </div>
        <div class="container">
            <div class="banner_content text-center">
                <h3 style="color:white;" data-aos="fade-up" data-aos-duration="1600">School of Business <br /> Sanata Dharma University</h3>
                <a data-aos="fade-up" data-aos-duration="2000" class="main_btn" href="<?= base_url('/materi/elearning') ?>">E-learning <span class="lnr lnr-arrow-right"></span></a>
            </div>
        </div>
    </div>
</section>

<!-- ================End Home Banner Area ================= -->

<!--================Finance Area =================-->
<style>
img {
max-width: 100%;
height: auto;
width: auto\9; /* ie8 */
}
</style>
<link rel="stylesheet" href="<?= base_url('assets/') ?>css/stylekegiatan.css">
<section class="finance_area">

    <div class="container">
        <div class="finance_inner row">
            <div class="col-lg-12 col-xs-12">
                <div class="finance_item">
                    <div data-aos="fade-up" data-aos-duration="1600" class="media">
						<div style="max-width:1920px;">		
							<img style="padding-bottom:100px;"src="<?= base_url('assets/') ?>img/partner/partner.png" alt="">
						</div>
                    </div>
					<div class="row justify-content-center" data-aos="fade-up" data-aos-duration="1600">
                    <!-- Single Latest Sermons -->
					<?php
					foreach ($activity as $d) { 
                        echo '<div class="col-12 col-sm-4 col-lg-4">
                            <div class="single-latest-sermons mb-100">
									<div class="sermons-thumbnail">
										<a href="'.base_url("kegiatan/detailEvent/").$d->id.'"><img style="width:100%;height:auto;" src="'.base_url("learning/vendor/images/img_Activities/").$d->image.'" style="width: 27em" alt=""></center></a>
										<!-- Date -->
										<div class="sermons-date">
											<h6><span>'.substr(date("d-M-Y", strtotime($d->timestamp)),0,2).'</span>'.substr(date("d-M-Y", strtotime($d->timestamp)),3,3).'</h6>
										</div>
									</div>
									<div class="sermons-content">
										<div class="about-us-content mb-100">
											<div class="about-text">
												<a href="'.base_url('kegiatan/detailEvent/').$d->id.'"><h4>'.$d->title_en.'</h4></a>
												<p>'.substr(filter_var($d->content_en, FILTER_SANITIZE_STRING),0,100).' . . .'.'</p>
												<a href="'.base_url('kegiatan/detailEvent/').$d->id.'">Baca Selengkapnya <i class="fa fa-angle-double-right"></i></a>
											</div>
										</div>
									</div>
								</div>
							</div>';
					}
						?>
					</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!--================End Finance Area =================-->
