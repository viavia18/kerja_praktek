<!doctype html>
<html lang="en">

<head>

    <!-- Required meta tags -->
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="<?= base_url('assets/') ?>img/usd.png" type="image/png">
    <title>School of Business Sanata Dharma University</title>
    <!-- Bootstrap CSS -->
	<style>
	 label {
     margin: 0;
     padding: 0;
     border: 0;
     font-size: 100%;
     font: inherit;
     vertical-align: baseline
 }
 .customRadio input[type="radio"] {
     position: absolute;
     left: -9999px;
 }

 .customRadio input[type="radio"]+label {
     position: relative;
     padding: 0 0 0 40px;
     cursor: pointer;
 }

 .customRadio input[type="radio"]+label:before {
     content: '';
     background: #fff;
     border: 2px solid #311B92;
     height: 25px;
     width: 25px;
     border-radius: 50%;
     position: absolute;
     top: 0;
     left: 0;
 }

 .customRadio input[type="radio"]+label:after {
     content: '';
     background: #311B92;
     width: 15px;
     height: 15px;
     border-radius: 50%;
     position: absolute;
     top: 5px;
     left: 5px;;
     opacity: 0;
     transform: scale(2);
     transition: transform 0.3s linear, opacity 0.3s linear
 }

 .customRadio input[type="radio"]:checked+label:after {
     opacity: 1;
     transform: scale(1)
 }
  .holder {
     padding: 0 0 30px;
     margin: 0 0 30px
 }

 .row {
     margin: 0 0 10px
 }
 
 img {
    max-width: 100%;
    height: auto;
    width: auto\9; /* ie8 */
}
}

 </style>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>css/bootstrap.css">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>vendors/linericon/style.css">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>css/font-awesome.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>vendors/lightbox/simpleLightbox.css">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>vendors/nice-select/css/nice-select.css">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>vendors/animate-css/animate.css">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>vendors/popup/magnific-popup.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/') ?>css/style.css">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>css/materi_style.css">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>css/responsive.css">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Library -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.10.4/dist/sweetalert2.all.min.js"></script>
	<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.10.4/dist/sweetalert2.all.min.js"></script>
    <script src="<?= base_url('assets/') ?>js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url('assets/') ?>js/popper.js"></script>
    <script src="<?= base_url('assets/') ?>js/bootstrap.min.js"></script>
    <script type="text/javascript">
        $(document).ready(() => {
            $("#nav<?= $this->uri->segment(2); ?>").addClass('active')
        })
    </script>


</head>

<body style="overflow-x:hidden;background-color:#fbf9fa;">


    <!-- Start Navigation Bar -->
    <header class="header_area" style="background-color: white !important;">
        <div class="main_menu">
            <nav class="navbar navbar-expand-lg navbar-light">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <a class="navbar-brand logo_h" href="<?= base_url('welcome') ?>"><img src="<?= base_url('assets/') ?>img/logo.png" alt=""></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
                        <ul class="nav navbar-nav menu_nav ml-auto">
                            <li class="nav-item" id="nav"><a class="nav-link" href="<?= base_url('welcome') ?>">Beranda</a></li>
                            <li class="nav-item" id="navtentang"><a class="nav-link" href="<?= base_url('materi/elearning') ?>">E-learning</a>
                            </li>
                            <li class="nav-item" id="navkontak"><a class="nav-link" href="<?= base_url('welcome/kegiatan') ?>">Kegiatan</a>
                            </li>
                            <li class="nav-item"><a class="nav-link" href="<?= base_url('welcome/profile') ?>">Profile</a></li>
							<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Bahasa </a>
							<div class="dropdown-menu">
								<a class="dropdown-item" href="<?= base_url('welcome') ?>/id">Indonesia <img src="<?= base_url('assets/') ?>img/id.png" alt=""></a>
								<a class="dropdown-item" href="<?= base_url('welcome') ?>/en">English <img src="<?= base_url('assets/') ?>img/en.png" alt=""></a>
							</div>
							</li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    <!-- End Navigation Bar -->


    <!-- Start Greeting Cards -->
	
    <div class="container">
        <div class="bg-white mx-auto p-4 buat-text" data-aos="fade-down" data-aos-duration="1400" style="width: 100%; border-radius:10px;">
            <div class="row" style="color: black; font-family: 'poppins';">
                <div class="col-md-12 mt-1 text-justify">
				<h2 data-aos="fade-down" data-aos-duration="1400">
				<?php
					foreach ($case as $c) {
						echo $c->title_ind;
					}
				?>
				</h2>
				<br>
				<div>
				<?php
					$video = '';
					$image = '';
					foreach ($question as $q) {
						if($q->video!=''){
							echo '<iframe width="100%" height="400px" src="https://www.youtube.com/embed/'.$q->video.'" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
						}
						else if ($q->image!=''){
							echo '<img width="100%" height="400px" src="'.base_url('assets/img/img_Questions/').$q->image.'" alt="">';
						}
					
				?>
				<!--
                    <iframe width="100%" height="400px" src="https://www.youtube.com/embed/cMBDfInvrjE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					<img width="100%" height="400px" src="<?= base_url('assets/') ?>img/elements/g2.jpg" alt="">
				-->
				</div>
                    <hr width="80%">
                    <p style="text-align:left;"data-aos="fade-down" class="font-weight" data-aos-duration="1800">
					<?php
						echo $q->content_ind;
					?>
                    </p>
					<br>
					<p style="text-align:left;"data-aos="fade-down" class="font-weight" data-aos-duration="1800">
					<?php
						echo $q->question_ind;
					}
					?>
                    </p>
					<div style="padding-left:40px;" class="col-lg-8">
						<div class="holder">
						
                            <form action="<?php
							$button_text ='Pilih';
						if(sizeof($answers)=='0'){
							$arr = $_SESSION['questions_active'];
							if(empty($arr))
							{
								echo 'review';
								$button_text = 'Review Case';
							}
							else {
								echo 'question';
								$id_question = end($arr);
								array_pop($arr);
								$_SESSION['questions_active'] = $arr;
								$button_text = 'Selanjutnya';
							}
						}
						else {
							echo 'answer';
						}
						;?>" class="customRadio customCheckbox m-0 p-0">
								<input type="hidden" name="id_question" value="<?=$id_question;?>">
								<input type="hidden" name="id_case" value="<?=$id_case;?>">
                                <div class="row mb-0">
                                    <div class="row justify-content-start">
                                        <div class="col-12">
											<?php
												$i='a';
												foreach ($answers as $a) {
													echo
													' <div class="row">
												<div style="max-width:500px;">											
												<input type="radio" name="id_answer" id="'.$i.'" value="'.$a->id.'"><label for="'.$i.'"><p style="text-align:left;">'.$a->option_ind.'</p></label><br>
												</div>
												</div>';
												$i++;
												}
											?>
                                           
											<div class="col-md-12 text-center">
												<button type="submit" value="submit" class="btn submit_btn"><?php echo $button_text;?></button>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
					</div>
                </div>
				
				
            </div>
        </div>
    </div>
    <!-- End Greeting Cards -->


    <!-- Start Lesson Cards -->
    <div class="container">
        <div class="row mt-4">
		<!--
            <?php foreach ($materi as $u) { ?>
                <div class="col-md-6 mb-4" data-aos="fade-right" data-aos-duration="1200">
                    <div class="card materi w-150 border-0">
                        <div class="card-body p-5">
                            <h1 class="card-title"><?= $u->nama_guru; ?></h1>
                            <p class=" card-text">
                                <?= substr($u->deskripsi, 0, 100); ?>&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.&nbsp;.
                            </p>
                            <a href="<?php echo site_url('materi/belajar/' . $u->id); ?>" class="btn btn-white">Pelajari
                                Sekarang !</a>
                        </div>
                    </div>
                </div>
            <?php } ?>
			--!>
        </div>
    </div>
    <!-- End Lesson Cards -->


    <br>


    <!-- Start Animate On Scroll -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <!-- End Animate On Scroll -->