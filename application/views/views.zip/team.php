<!--================Contact Area =================-->
<link rel="stylesheet" href="<?= base_url('assets/') ?>css/stylekegiatan.css">        
    <div class="team-members-area section-padding-100-0">
            <div class="container">
                <div class="row">
                    <!-- Section Heading -->
                    <div class="col-12">
                        <div class="section-heading">
                            <h2>Lorem Ipsum</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Team Members Area -->
                    <div class="col-12 col-sm-6 col-lg-4">
                        <div class="single-team-members text-center mb-100">
                            <div class="team-thumb" style="background-image: url(https://img2.pngdownload.id/20180614/vzk/kisspng-computer-icons-anonymous-anonymity-5b2333ee0ec363.3736667315290337100605.jpg);background-size:200px 200px;">
                                <div class="team-social-info">
                                    <a href="mailto:joko_sis@usd.ac.id"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <h6>Dr. FA. Joko Siswantoc</h6>
                            <span>Project Leader</span>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-4">
                        <div class="single-team-members text-center mb-100">
                            <div class="team-thumb" style="background-image: url(https://img2.pngdownload.id/20180614/vzk/kisspng-computer-icons-anonymous-anonymity-5b2333ee0ec363.3736667315290337100605.jpg);background-size:200px 200px;">
                                <div class="team-social-info">
                                    <a href="mailto:reni@usd.ac.id"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <h6>Dr. Fr. Reni Retno Anggraini</h6>
                            <span>Vice Project Leader 1</span>
                        </div>
                    </div>

                    <div class="col-12 col-sm-6 col-lg-4">
                        <div class="single-team-members text-center mb-100">
                            <div class="team-thumb" style="background-image: url(https://img2.pngdownload.id/20180614/vzk/kisspng-computer-icons-anonymous-anonymity-5b2333ee0ec363.3736667315290337100605.jpg);background-size:200px 200px;">
                                <div class="team-social-info">
                                    <a href="mailto:novitadewi@usd.ac.id"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <h6>Dra. Novita Dewi, Ph.D.</h6>
                            <span>Vice Project Leader 2</span>
                        </div>
                    </div>

                    <!-- Team Members Area -->
                    <div class="col-12 col-sm-6 col-lg-4">
                        <div class="single-team-members text-center mb-100">
                            <div class="team-thumb" style="background-image: url(https://img2.pngdownload.id/20180614/vzk/kisspng-computer-icons-anonymous-anonymity-5b2333ee0ec363.3736667315290337100605.jpg);background-size:200px 200px;">
                                <div class="team-social-info">
                                    <a href="mailto:karsana0105@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <h6>Dr. Yusef Widya Karsana</h6>
                            <span>Vice Project Leader 3</span>
                        </div>
                    </div>

                    <!-- Team Members Area -->
                    <div class="col-12 col-sm-6 col-lg-4">
                        <div class="single-team-members text-center mb-100">
                            <div class="team-thumb" style="background-image: url(https://img2.pngdownload.id/20180614/vzk/kisspng-computer-icons-anonymous-anonymity-5b2333ee0ec363.3736667315290337100605.jpg);background-size:200px 200px;">
                                <div class="team-social-info">
                                    <a href="mailto:gabriel.mbeling@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <h6>Agnes Maria Polina, S.Kom, M.Sc.</h6>
                            <span>Vice Project Leader 4</span>
                        </div>
                    </div>
                    
                    <!-- Team Members Area -->
                    <div class="col-12 col-sm-6 col-lg-4">
                        <div class="single-team-members text-center mb-100">
                            <div class="team-thumb" style="background-image: url(https://img2.pngdownload.id/20180614/vzk/kisspng-computer-icons-anonymous-anonymity-5b2333ee0ec363.3736667315290337100605.jpg);background-size:200px 200px;">
                                <div class="team-social-info">
                                    <a href="mailto:felix.prihantoro@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <h6>Felix Prihantoro</h6>
                            <span>Programmer</span>
                        </div>
                    </div>
					
                    <!-- Team Members Area -->
                    <div class="col-12 col-sm-6 col-lg-4">
                        <div class="single-team-members text-center mb-100">
                            <div class="team-thumb" style="background-image: url(https://img2.pngdownload.id/20180614/vzk/kisspng-computer-icons-anonymous-anonymity-5b2333ee0ec363.3736667315290337100605.jpg);background-size:200px 200px;">
                                <div class="team-social-info">
                                    <a href="mailto:felix.prihantoro@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                                </div>
                            </div>
                            <h6>Tandrianto Koko Gunawan</h6>
                            <span>Programmer</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<!--================Contact Area =================-->