<!--================Home Banner Area =================-->
<section class="banner_area">
    <div class="banner_inner d-flex align-items-center">
        <div class="kontak bg-parallax" data-stellar-ratio="0.9" data-stellar-vertical-offset="0" data-background="">
        </div>
        <div class="container">
            <div class="banner_content text-center">
                <h2 data-aos="fade-up" data-aos-duration="1600">Event</h2>
                <div data-aos="fade-up" data-aos-duration="1600" class="page_link">
                    <a href="<?= base_url('/') ?>">Home</a>
                    <a href="<?= base_url('/kegiatan') ?>">Event</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================End Home Banner Area =================-->

<!--================Contact Area =================-->
<link rel="stylesheet" href="<?= base_url('assets/') ?>css/stylekegiatan.css">        
    <div class="blog-area section-padding-40">
        <div class="container">
			<div class="bg-white mx-auto p-4 buat-text" data-aos="fade-up" data-aos-duration="1400" style="width: 100%; border-radius:10px;">

                    <!-- Blog Post Area -->
					<div class="col-12 col-lg-6 text-center">

                        <?php
							$no = $this->uri->segment('3') + 1;						
							foreach ($activity as $d) { 
								echo '<div class="sermons-content-area">
										<div class="row">
											<div class="col-12">
												<div class="sermons-content-thumbnail">
													<a href="'.base_url("kegiatan/detailEvent/").$d->id.'"><img src="'.base_url("assets/img/img_Activities/").$d->image.'" alt=""></a>                                            
												</div>
												<!-- Sermons Text -->
												<div class="sermons-text text-center">
													<a href="'.base_url("kegiatan/detailEvent/").$d->id.'"><h4>'.$d->title_en.'</h4></a>
													<div class="sermons-meta-data d-flex flex-wrap justify-content-center">
														<p><i class="fa fa-calendar" aria-hidden="true"></i>'.' '.date("d-M-Y", strtotime($d->timestamp)).'</p>
													</div>
													'.substr(filter_var($d->content_en, FILTER_SANITIZE_STRING),0,100).' . . .'.'
													<div class="read-more-share d-flex flex-wrap justify-content-between">
														<div class="read-more-btn">
															<a href="'.base_url("kegiatan/detailEvent/").$d->id.'">Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
														</div>
													</div>
												</div>
											</div>
										</div>
								</div>';
							}
							?>
							<div class="row">
                            <div class="pagination-area">
                                <!--Tampilkan pagination-->
                                <div class="pagging text-center">
									<nav><ul class="pagination justify-content-center">
									<?php 
										echo $this->pagination->create_links();
									?>
									</ul></nav>
								</div>                            
							</div>
                        </div>
                    </div>
					

                    <!-- Sidebar Area -->
                    

            </div>
        </div>
        </div>
<!--================Contact Area =================-->